public class spell {
    private int[][] damages;
    private int manacost;
    private int rerollcost;
    private String name;
    private String rarity;
    private int tier;
    public spell(int[][] dmg, int mc, int rc, String n, String r) {
        damages = dmg;
        manacost = mc;
        rerollcost = rc;
        name = n;
        rarity = r;
        tier = 1;
    }

    //GETTERS
    public int getMC() {
        return getMC();
    }
    //SETTERS

    //OTHERS
    public int[] rollDmg(int[] skills) {
        int[] values = new int[6];
        for (int i=0; i<6; i++) {
            values[i] = (int) (Math.random()*(damages[1][i]-damages[0][i]+1))+damages[0][i];
        }
        return values;
    }
}