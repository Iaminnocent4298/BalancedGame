public class mob {
    private int maxhp;
    private double hp;
    private int[][] damages;
    private int[][] defences;
    private Object[] lootpool;
    private double[] chances;
}
